const users = [
    { username: "admin", password: "admin123" },
    { username: "student1", password: "mathrocks" },
    { username: "teacher1", password: "teach2025" }
  ];
  